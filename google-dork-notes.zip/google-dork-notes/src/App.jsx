import React from 'react'
import GoogleDorkNotesApp from './components/GoogleDorkNotesApp'


export default function App(){
return <GoogleDorkNotesApp />
}
